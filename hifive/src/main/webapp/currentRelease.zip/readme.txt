hifive depends on :

    jquery-1.7.1+ (http://jquery.com/)
    jquery.blockUI (http://jquery.malsup.com/block/)

you can include these libraries like this:

		<!doctype html>
		<html>
			<head>
				<meta charset="UTF-8">
				<link type="text/css" rel="stylesheet" href="lib/h5/h5.css">
				<script src="lib/jquery/jquery.js"></script>
				<script src="lib/jquery/plugin/jquery.blockUI.js"></script>
				<script src="lib/ejs/ejs-1.0.h5mod.js"></script>
				<script src="lib/h5/h5.js"></script>
			</head>
			<body>
				...
			</body>
		</html>


